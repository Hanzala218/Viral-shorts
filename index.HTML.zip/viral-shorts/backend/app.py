"""
Viral Shorts Maker - production backend.
Hardened: domain allowlist, rate limits, per-IP job cap, size/duration limits,
SQLite-persisted jobs, worker pool, auto cleanup, optional access code, file upload.
Run with gunicorn using ONE process (-w 1) and several threads (see Dockerfile).
"""
import os, re, json, time, glob, hmac, shutil, sqlite3, secrets, logging, threading
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse
from flask import Flask, request, jsonify, send_from_directory
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import yt_dlp
import pipeline

E = os.environ.get
BASE = os.path.dirname(os.path.abspath(__file__))
FRONTEND = os.path.join(BASE, "..", "frontend")
DATA_DIR = E("DATA_DIR", os.path.join(BASE, "data"))
JOBS_DIR = os.path.join(DATA_DIR, "jobs")
DB_PATH = os.path.join(DATA_DIR, "jobs.db")
os.makedirs(JOBS_DIR, exist_ok=True)

ALLOWED_DOMAINS = [d.strip().lower() for d in E("ALLOWED_DOMAINS", "youtube.com,youtu.be,vimeo.com").split(",") if d.strip()]
MAX_DURATION_MIN = int(E("MAX_DURATION_MIN", "60"))
MAX_UPLOAD_MB = int(E("MAX_UPLOAD_MB", "500"))
MAX_WORKERS = int(E("MAX_WORKERS", "1"))            # parallel video jobs (CPU heavy!)
MAX_ACTIVE_PER_IP = int(E("MAX_ACTIVE_PER_IP", "2"))
RETENTION_HOURS = int(E("RETENTION_HOURS", "24"))
ACCESS_CODE = E("ACCESS_CODE", "")                  # empty = public site
COOKIES_FILE = E("COOKIES_FILE", "")                # optional yt-dlp cookies.txt
UPLOAD_EXT = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"}

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("shorts")

app = Flask(__name__, static_folder=None)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)  # behind Caddy
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024 + 1024 * 1024
limiter = Limiter(get_remote_address, app=app, default_limits=["600/hour"], storage_uri="memory://")
pool = ThreadPoolExecutor(max_workers=MAX_WORKERS)


class UserError(Exception):
    """Message is safe to show to the user."""


# ------------------------------------------------------------------ database
def q(sql, args=(), one=False):
    c = sqlite3.connect(DB_PATH, timeout=30)
    c.row_factory = sqlite3.Row
    try:
        cur = c.execute(sql, args)
        c.commit()
        rows = cur.fetchall()
        return (rows[0] if rows else None) if one else rows
    finally:
        c.close()


def init_db():
    q("""CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, ip TEXT, status TEXT,
         progress INTEGER, message TEXT, clips TEXT, created REAL)""")
    q("UPDATE jobs SET status='error', message='Server restart hua, dobara try karein.' "
      "WHERE status NOT IN ('done','error')")


def update(job_id, **kw):
    if "clips" in kw:
        kw["clips"] = json.dumps(kw["clips"])
    sets = ", ".join(f"{k}=?" for k in kw)
    q(f"UPDATE jobs SET {sets} WHERE id=?", (*kw.values(), job_id))


# ---------------------------------------------------------------- validation
def allowed_url(url):
    p = urlparse(url)
    if p.scheme != "https" or not p.hostname:
        return False
    h = p.hostname.lower()
    return any(h == d or h.endswith("." + d) for d in ALLOWED_DOMAINS)


def check_access():
    if ACCESS_CODE and not hmac.compare_digest(request.headers.get("X-Access-Code", ""), ACCESS_CODE):
        return jsonify(error="Access code galat hai."), 401
    return None


def int_arg(src, key, default, lo, hi):
    try:
        return max(lo, min(int(src.get(key, default)), hi))
    except (TypeError, ValueError):
        return default


def new_job(kind_ok_dir=True):
    ip = get_remote_address()
    active = q("SELECT COUNT(*) AS n FROM jobs WHERE ip=? AND status NOT IN ('done','error')", (ip,), one=True)["n"]
    if active >= MAX_ACTIVE_PER_IP:
        return None, None, (jsonify(error="Aapke pehle se jobs chal rahe hain. Unke khatam hone ka intezaar karein."), 429)
    job_id = secrets.token_hex(12)
    q("INSERT INTO jobs VALUES(?,?,?,?,?,?,?)", (job_id, ip, "queued", 0, "Queue mein hai...", "[]", time.time()))
    d = os.path.join(JOBS_DIR, job_id)
    os.makedirs(d, exist_ok=True)
    return job_id, d, None


# ------------------------------------------------------------------ pipeline
def download(url, job_dir):
    opts = {
        "format": "bv*[height<=1080]+ba/b[height<=1080]/b",
        "merge_output_format": "mp4",
        "outtmpl": os.path.join(job_dir, "source.%(ext)s"),
        "noplaylist": True, "quiet": True, "socket_timeout": 30, "retries": 3,
        "max_filesize": 2 * 1024 ** 3,
    }
    if COOKIES_FILE and os.path.exists(COOKIES_FILE):
        opts["cookiefile"] = COOKIES_FILE
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
            if info.get("is_live"):
                raise UserError("Live stream support nahi hai.")
            if (info.get("duration") or 0) > MAX_DURATION_MIN * 60:
                raise UserError(f"Video {MAX_DURATION_MIN} minute se chhoti honi chahiye.")
            ydl.download([url])
    except yt_dlp.utils.DownloadError as e:
        log.warning("download failed: %s", e)
        raise UserError("Video download nahi ho paya (private, blocked ya galat link).")
    return find_source(job_dir)


def find_source(job_dir):
    files = [f for f in glob.glob(os.path.join(job_dir, "source.*")) if not f.endswith((".part", ".ytdl"))]
    if not files:
        raise UserError("Video file nahi mili.")
    return files[0]


def run_job(job_id, kind, url, n, min_len, max_len):
    job_dir = os.path.join(JOBS_DIR, job_id)
    try:
        if kind == "url":
            update(job_id, status="downloading", progress=10, message="Video download ho raha hai...")
            src = download(url, job_dir)
        else:
            src = find_source(job_dir)
        if pipeline.probe_duration(src) > MAX_DURATION_MIN * 60:
            raise UserError(f"Video {MAX_DURATION_MIN} minute se chhoti honi chahiye.")

        update(job_id, status="transcribing", progress=35, message="Speech ko text mein badal rahe hain...")
        segs = pipeline.transcribe(src)
        if not segs:
            raise UserError("Video mein koi speech nahi mili.")

        update(job_id, status="analyzing", progress=55, message="Best viral moments dhoondh rahe hain...")
        picks = pipeline.pick_clips(segs, n, min_len, max_len)
        if not picks:
            raise UserError("Is video mein se koi short nahi ban paya. Chhoti length try karein.")

        clips = []
        for i, c in enumerate(picks, 1):
            update(job_id, status="rendering", progress=60 + int(35 * i / len(picks)),
                   message=f"Short {i}/{len(picks)} ban raha hai (captions ke sath)...")
            fname = pipeline.render_clip(job_dir, src, c, segs, i)
            clips.append({"file": fname, "start": round(c["start"], 1), "end": round(c["end"], 1),
                          "score": round(c["score"], 1),
                          "title": " ".join(segs[c["i"]]["text"].split()[:10]),
                          "url": f"/api/clips/{job_id}/{fname}"})
        for f in glob.glob(os.path.join(job_dir, "source.*")) + glob.glob(os.path.join(job_dir, "*.ass")):
            os.remove(f)  # save disk
        update(job_id, status="done", progress=100, message="Ho gaya!", clips=clips)
    except UserError as e:
        update(job_id, status="error", message=str(e))
    except Exception:
        log.exception("job %s failed", job_id)
        update(job_id, status="error", message="Processing fail ho gaya. Thodi der baad dobara try karein.")


# -------------------------------------------------------------------- routes
@app.post("/api/jobs")
@limiter.limit("10/hour;3/minute")
def create_job():
    if (resp := check_access()):
        return resp
    data = request.get_json(silent=True) or {}
    url = (data.get("url") or "").strip()
    if not data.get("accepted"):
        return jsonify(error="Pehle confirm karein ki video par aapka haq/permission hai."), 400
    if not allowed_url(url):
        return jsonify(error="Sirf is sites ke https links allowed hain: " + ", ".join(ALLOWED_DOMAINS)), 400
    job_id, _, err = new_job()
    if err:
        return err
    n = int_arg(data, "clips", 5, 1, 8)
    pool.submit(run_job, job_id, "url", url, n, int_arg(data, "min_len", 20, 10, 60), int_arg(data, "max_len", 55, 15, 90))
    return jsonify(job_id=job_id)


@app.post("/api/upload")
@limiter.limit("10/hour;3/minute")
def upload():
    if (resp := check_access()):
        return resp
    f = request.files.get("file")
    if request.form.get("accepted") != "true":
        return jsonify(error="Pehle confirm karein ki video par aapka haq/permission hai."), 400
    ext = os.path.splitext(f.filename or "")[1].lower() if f else ""
    if ext not in UPLOAD_EXT:
        return jsonify(error="Supported formats: " + ", ".join(sorted(UPLOAD_EXT))), 400
    job_id, job_dir, err = new_job()
    if err:
        return err
    f.save(os.path.join(job_dir, "source" + ext))
    n = int_arg(request.form, "clips", 5, 1, 8)
    pool.submit(run_job, job_id, "upload", None, n, int_arg(request.form, "min_len", 20, 10, 60), int_arg(request.form, "max_len", 55, 15, 90))
    return jsonify(job_id=job_id)


@app.get("/api/jobs/<job_id>")
def job_status(job_id):
    if not re.fullmatch(r"[0-9a-f]{24}", job_id):
        return jsonify(error="Job nahi mila"), 404
    r = q("SELECT status, progress, message, clips FROM jobs WHERE id=?", (job_id,), one=True)
    if not r:
        return jsonify(error="Job nahi mila (ya delete ho chuka hai)"), 404
    return jsonify(status=r["status"], progress=r["progress"], message=r["message"], clips=json.loads(r["clips"]))


@app.get("/api/clips/<job_id>/<name>")
def get_clip(job_id, name):
    if not re.fullmatch(r"clip\d+\.mp4", name) or not re.fullmatch(r"[0-9a-f]{24}", job_id):
        return "Not found", 404
    dl = request.args.get("download") == "1"
    return send_from_directory(os.path.join(JOBS_DIR, job_id), name, as_attachment=dl, download_name=f"short_{name}")


@app.get("/api/health")
def health():
    return jsonify(ok=True)


@app.get("/")
def index():
    return send_from_directory(FRONTEND, "index.html")


CORS_ORIGIN = E("CORS_ORIGIN", "")  # e.g. https://mysite.com ; leave empty if Flask serves the page


@app.after_request
def cors(resp):
    if CORS_ORIGIN:
        resp.headers["Access-Control-Allow-Origin"] = CORS_ORIGIN
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type, X-Access-Code"
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return resp


@app.errorhandler(429)
def too_many(_):
    return jsonify(error="Bahut zyada requests. Thodi der baad try karein."), 429


@app.errorhandler(413)
def too_big(_):
    return jsonify(error=f"File {MAX_UPLOAD_MB} MB se badi hai."), 413


# ------------------------------------------------------------------- cleanup
def cleanup_loop():
    while True:
        try:
            cutoff = time.time() - RETENTION_HOURS * 3600
            for r in q("SELECT id FROM jobs WHERE created < ? AND status IN ('done','error')", (cutoff,)):
                shutil.rmtree(os.path.join(JOBS_DIR, r["id"]), ignore_errors=True)
                q("DELETE FROM jobs WHERE id=?", (r["id"],))
        except Exception:
            log.exception("cleanup failed")
        time.sleep(1800)


for tool in ("ffmpeg", "ffprobe"):
    if not shutil.which(tool):
        raise SystemExit(f"ERROR: {tool} install nahi hai. Pehle FFmpeg install karein aur PATH mein jodein.")

init_db()
threading.Thread(target=cleanup_loop, daemon=True).start()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)
